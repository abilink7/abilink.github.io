<div class="wrap">
<h1 style="text-align: center;">Режим технического обслуживания</h1>
<p style="text-align: center;">В данный момент сайт находится на техническом обслуживании.
Приносим извинения за временные неудобства.
Спасибо за понимание.</p>
<p style="text-align: center;"><a href="http://abilink.at.ua" target="_blank" rel="noopener">http://abilink.at.ua</a></p>

</div>