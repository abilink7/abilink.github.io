/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'az', {
	border: 'Çərçivə sərhədlərini göstər',
	noUrl: 'Çərçivənin ünvanı daxil edin',
	scrolling: 'Şürüşdürmələri əlavə et',
	title: 'İFRAME elementinin alətləri',
	toolbar: 'İFRAME'
} );
