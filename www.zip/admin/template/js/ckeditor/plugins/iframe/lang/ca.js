/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ca', {
	border: 'Mostra la vora del marc',
	noUrl: 'Si us plau, introdueixi la URL de l\'iframe',
	scrolling: 'Activa les barres de desplaçament',
	title: 'Propietats de l\'IFrame',
	toolbar: 'IFrame'
} );
