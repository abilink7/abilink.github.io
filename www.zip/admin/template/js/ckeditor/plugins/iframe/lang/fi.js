/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fi', {
	border: 'Näytä kehyksen reunat',
	noUrl: 'Anna IFrame-kehykselle lähdeosoite (src)',
	scrolling: 'Näytä vierityspalkit',
	title: 'IFrame-kehyksen ominaisuudet',
	toolbar: 'IFrame-kehys'
} );
