/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'es-mx', {
	border: 'Mostrar el borde del marco',
	noUrl: 'Ingresa la URL del iframe',
	scrolling: 'Habilitar la barra de desplazamiento',
	title: 'Propiedades del IFrame',
	toolbar: 'Iframe'
} );
