/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'oc', {
	border: 'Afichar la bordadura del quadre',
	noUrl: 'Entratz l\'URL del contengut del quadre',
	scrolling: 'Activar las barras de desfilament',
	title: 'Proprietats del quadre de contengut incorporat',
	toolbar: 'Quadre de contengut incorporat'
} );
