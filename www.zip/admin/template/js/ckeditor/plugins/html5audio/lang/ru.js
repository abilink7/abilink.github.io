CKEDITOR.plugins.setLang( 'html5audio', 'ru', {
    button: 'Вставить HTML5 аудио',
    title: 'HTML5 аудио',
    infoLabel: 'Аудио',
    urlMissing: 'Не выбран источник аудио',
    audioProperties: 'Свойства аудио'
} );
