/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'chart', 'ru', {
	bar: 'Столбы',
	chart: 'Диаграмма',
	chartType: 'Тип диаграммы:',
	dialogTitle: 'Создать диаграмму',
	doughnut: 'Кольцо',
	height: 'Высота:',
	label: 'Метка:',
	line: 'Линия',
	pie: 'Круг',
	polar: 'Дольки',
	value: 'Значение:'
} );